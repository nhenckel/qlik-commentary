define(["qlik"], function (qlik) {
  return {
    type: "items",
    component: "accordion",
    items: {
      appearance: {
        uses: "settings",
      },

      /** 🌍 Global Settings **/
      globalSettings: {
        type: "items",
        label: "Global Settings",
        grouped: true,
        items: {
          applySelectionsButtonGroup: {
            type: "items",
            items: {
              applySelectionsButtonDescription: {
                component: "text",
                label:
                  "Display an 'Apply Selections' button on each comment. When enabled, users can restore the dashboard filters that were active when the comment was created or last edited.",
              },
              applySelectionsButton: {
                ref: "props.applySelectionsButton",
                type: "boolean",
                component: "switch",
                options: [
                  { value: true, label: "On" },
                  { value: false, label: "Off" },
                ],
                defaultValue: true,
                label: "Apply Selections Button",
              },
            },
          },
          editWindowDaysGroup: {
            type: "items",
            items: {
              editWindowDaysDescription: {
                component: "text",
                label: "Sets how many days a user can edit their comments after posting.",
              },
              editWindowDays: {
                ref: "props.editWindowDays",
                type: "number",
                defaultValue: 7,
              },
            },
          },
          filterDaysGroup: {
            type: "items",
            label: "Filtering Settings",
            items: {
              filterDaysDescription: {
                component: "text",
                label:
                  "Display only comments that are at most this many days old (comments older than this will be filtered out).",
              },
              filterDays: {
                ref: "props.filterDays",
                type: "number",
                defaultValue: 30,
                label: "Filter Days",
              },
            },
          },
          userProfileUrlGroup: {
            type: "items",
            items: {
              userProfileUrlDescription: {
                component: "text",
                label:
                  "Optional. Creates a hyperlink for the commenter's username. Use {{id}} in the URL to dynamically insert the user's ID. Example: example.com/profile/{{id}}",
              },
              userProfileUrl: {
                ref: "props.userProfileUrl",
                type: "string",
                expression: "optional",
                defaultValue: "",
              },
            },
          },
          userAvatarTemplateGroup: {
            type: "items",
            items: {
              userAvatarTemplateDescription: {
                component: "text",
                label:
                  "Optional. Defines the URL template for user avatars. Use {{id}} to dynamically insert the user's ID. Example: example.com/images/avatar_{{id}}.jpg",
              },
              userAvatarTemplate: {
                ref: "props.userAvatarTemplate",
                type: "string",
                expression: "optional",
                defaultValue: "",
              },
            },
          },
        },
      },

      /** 🎨 UI Settings **/
      uiSettings: {
        type: "items",
        label: "UI Settings",
        grouped: true,
        items: {
          modeGroup: {
            type: "items",
            items: {
              modeDescription: {
                component: "text",
                label:
                  "Select Fixed Panel for a single-thread discussion or Floating Bubbles to attach comments to specific objects.",
              },
              mode: {
                ref: "props.mode",
                type: "string",
                component: "dropdown",
                options: [
                  { value: "fixed", label: "Fixed Panel" },
                  { value: "bubble", label: "Floating Bubbles" },
                ],
                defaultValue: "fixed",
              },
            },
          },

          /** 📝 Fixed Panel Settings **/
          fixedPanelGroup: {
            type: "items",
            label: "Fixed Panel Settings",
            show: function (data) {
              return data.props.mode === "fixed";
            },
            items: {
              fixedPanelDescription: {
                component: "text",
                label:
                  "The Fixed Panel groups comments into a thread based on threadId. This should be a Qlik expression that resolves to a unique identifier, such as a KPI or metric ID. Comments are stored under this threadId and retrieved when the expression evaluates to the same value.",
              },
              fixedPanelThreadId: {
                ref: "props.fixedPanelThreadId",
                label: "threadId",
                type: "string",
                expression: "optional",
                defaultValue: "global",
              },
            },
          },

          /** 💬 Floating Bubble Settings **/
          bubbleConfigGroup: {
            type: "items",
            label: "Floating Bubble Settings",
            show: function (data) {
              return data.props.mode === "bubble";
            },
            items: {
              bubbleEntryDescription: {
                component: "text",
                label:
                  "qId is the Qlik object ID where the bubble appears. threadId must be a fixed identifier (no expressions) for the bubble's comment thread, ensuring comments remain consistent regardless of selections.",
              },
              bubbleConfig: {
                type: "array",
                ref: "props.bubbleConfig",
                itemTitleRef: "qId",
                allowAdd: true,
                allowRemove: true,
                addTranslation: "Add Commentary Bubble",
                items: {
                  qId: {
                    ref: "qId",
                    label: "qId",
                    type: "string",
                    expression: "optional",
                  },
                  threadId: {
                    ref: "threadId",
                    label: "threadId",
                    type: "string",
                  },
                },
              },
            },
          },
        },
      },
    },
  };
});
