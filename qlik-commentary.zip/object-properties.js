define([], function () {
  return {
    showTitles: false,
    props: { threadIdExpression: "global" },
  };
});
