define(["qlik", "./bundle", "./extDefinition", "./object-properties"], function (
  qlik,
  bundle,
  extDefinition,
  properties
) {
  return {
    initialProperties: properties,
    definition: extDefinition,
    support: {
      snapshot: false,
      export: true,
      sharing: false,
      exportData: true,
    },
    paint: function ($element, layout) {
      // console.log("🖌️ paint() called, layout:", layout);

      const enigmaModel = this.backendApi.model.session.app.enigmaModel;
      // console.log("enigmaModel:", enigmaModel);

      try {
        bundle.render($element[0], { layout, enigmaModel }); // ✅ React handles rendering
      } catch (err) {
        console.error("❌ React rendering error in paint():", err);
      }
    },
  };
});
